#include<stdio.h>
#include<stdlib.h>

int main()
{int a,b,c,d;
printf("a\n");
printf("bb\n");
printf("ccc\n");
printf("dddd\n");
return 0;
}
