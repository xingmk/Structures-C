#include<stdio.h>
#include<stdlib.h>
int main()
{
double z=9.0/5.0;
double r1;
double r2;
printf("3,5:");
scanf("%1f,%1f",&r1,&r2);
printf("并联电阻为:%2lf/n 串联电阻为:%wlf/n",
		(r1*r2)/(r1+r2),r1+r2);
return 0;

}
