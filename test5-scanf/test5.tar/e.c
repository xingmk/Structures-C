#include<stdio.h>
#include<math.h>


int main()
{
 char a,b,c;
 double aver;
printf("shuru");
scanf("%c%c%c,&a,&b,&c);
aver=((int)a+(int)b+(int)c)/3.0-48;
printf("%lf",aver);

return 0;

}
