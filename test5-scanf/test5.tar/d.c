#include<stdio.h>
#include<stdlib.h>
int main()
{

int a,b,fa,sa,fb,sb,resp;
printf("请输入");
scanf("%d%d",&a,&b);
fa=a/10,fb=b/10,sa=a%10,sb=b%10;
resp=fa*1000+fb*100+sa*10+sb;
printf("respose%d\n",resp);
return 0;
}
